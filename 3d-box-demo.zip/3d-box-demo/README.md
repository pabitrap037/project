# 3d-box-demo

This is a small Babylon.JS-based webapp that displays a 3D model and draws boundary boxes at certain points. Clicking the boxes or the model will center the camera on either one of them. Rotate and zoom with mouse.  

### Execution 
1. Run a static server at the root of the project, like the following: `python3 -m http.server`
1. Navigate to the url and open with points, sizes and messages parameter, such as this: `http://localhost:8000/?points=[[-6,2,3],[5,4,2.5]]&sizes=[1,1]&messages=[%22Wing%20tip%20slightly%20bent%22,%20%22Weird%20noise%20coming%20from%20right%20engine%22]`. In this case, the parameters are the following:
    1. Center of the boxes: `points=[[-6,2,3],[5,4,2.5]]`
    2. Edge size of each box: `sizes=[1,1]`
    3. Messages that are shown if you click on a box: `messages=["Wing tip slightly bent", "Weird noise coming from right engine"]`

![Example](example.png)

